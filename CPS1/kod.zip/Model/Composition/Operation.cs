﻿namespace CPS1.Model.Composition
{
    public enum Operation
    {
        Add,
        Subtract,
        Multiply,
        Divide
    }
}