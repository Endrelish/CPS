﻿namespace CPS1.Model
{
    public enum Operation
    {
        Add,

        Subtract,

        Multiply,

        Divide
    }
}