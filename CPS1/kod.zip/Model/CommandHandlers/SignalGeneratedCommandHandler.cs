﻿namespace CPS1.Model.Delegates
{
    internal class SignalGeneratedCommandHandler
    {
    }
}