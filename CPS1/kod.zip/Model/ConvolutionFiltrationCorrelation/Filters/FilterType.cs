﻿namespace CPS1.Model.ConvolutionFiltrationCorrelation.Filters
{
    public enum FilterType
    {
        LowPassFilter,
        HighPassFilter
    }
}