﻿using System.Windows.Controls;

namespace CPS1.View
{
    /// <summary>
    ///     Interaction logic for AnalogDigitalSignalChart.xaml
    /// </summary>
    public partial class AnalogDigitalSignalChart : UserControl
    {
        public AnalogDigitalSignalChart()
        {
            InitializeComponent();
        }
    }
}