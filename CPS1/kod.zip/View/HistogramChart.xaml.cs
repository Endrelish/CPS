﻿namespace CPS1.View
{
    using System.Windows.Controls;

    /// <summary>
    ///     Interaction logic for HistogramChart.xaml
    /// </summary>
    public partial class HistogramChart : UserControl
    {
        public HistogramChart()
        {
            this.InitializeComponent();
        }
    }
}