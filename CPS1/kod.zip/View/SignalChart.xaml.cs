﻿namespace CPS1.View
{
    using System.Windows.Controls;

    /// <summary>
    ///     Interaction logic for SignalChart.xaml
    /// </summary>
    public partial class SignalChart : UserControl
    {
        public SignalChart()
        {
            this.InitializeComponent();
        }
    }
}