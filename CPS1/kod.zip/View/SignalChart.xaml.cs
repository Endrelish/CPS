﻿using System.Windows.Controls;

namespace CPS1.View
{
    /// <summary>
    ///     Interaction logic for SignalChart.xaml
    /// </summary>
    public partial class SignalChart : UserControl
    {
        public SignalChart()
        {
            InitializeComponent();
        }
    }
}