﻿using System.Windows.Controls;

namespace CPS1.View
{
    /// <summary>
    ///     Interaction logic for SignalSettings.xaml
    /// </summary>
    public partial class SignalSettings : UserControl
    {
        public SignalSettings()
        {
            InitializeComponent();
        }
    }
}