﻿namespace CPS1.View
{
    using System.Windows.Controls;

    /// <summary>
    ///     Interaction logic for SignalSettings.xaml
    /// </summary>
    public partial class SignalSettings : UserControl
    {
        public SignalSettings()
        {
            this.InitializeComponent();
        }
    }
}