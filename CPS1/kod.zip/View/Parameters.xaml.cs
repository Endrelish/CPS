﻿using System.Windows.Controls;

namespace CPS1.View
{
    /// <summary>
    ///     Interaction logic for Parameters.xaml
    /// </summary>
    public partial class Parameters : UserControl
    {
        public Parameters()
        {
            InitializeComponent();
        }
    }
}