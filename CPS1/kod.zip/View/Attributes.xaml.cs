﻿using System.Windows.Controls;

namespace CPS1.View
{
    /// <summary>
    ///     Interaction logic for Attributes.xaml
    /// </summary>
    public partial class Attributes : UserControl
    {
        public Attributes()
        {
            InitializeComponent();
        }
    }
}