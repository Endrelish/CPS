﻿using System.Windows.Controls;

namespace CPS1.View
{
    /// <summary>
    ///     Interaction logic for CompositionSettings.xaml
    /// </summary>
    public partial class CompositionSettings : UserControl
    {
        public CompositionSettings()
        {
            InitializeComponent();
        }
    }
}