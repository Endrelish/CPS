﻿using System.Windows.Controls;

namespace CPS1.View
{
    /// <summary>
    ///     Interaction logic for ConversionSettings.xaml
    /// </summary>
    public partial class ConversionSettings : UserControl
    {
        public ConversionSettings()
        {
            InitializeComponent();
        }
    }
}